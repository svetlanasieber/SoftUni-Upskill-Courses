public class Main {
    public static void main(String[] args) {
        String[] nones = ArrayCreator.create(10, "none");

        System.out.println(nones);
    }
}
