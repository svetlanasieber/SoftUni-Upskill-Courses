﻿namespace BirthdayCelebrations;

public interface IWithName
{
    string Name { get; }
}