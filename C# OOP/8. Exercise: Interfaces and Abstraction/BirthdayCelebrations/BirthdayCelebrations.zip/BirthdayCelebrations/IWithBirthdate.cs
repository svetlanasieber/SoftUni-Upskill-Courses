﻿namespace BirthdayCelebrations;

public interface IWithBirthdate
{
    string Birthdate { get; }
}