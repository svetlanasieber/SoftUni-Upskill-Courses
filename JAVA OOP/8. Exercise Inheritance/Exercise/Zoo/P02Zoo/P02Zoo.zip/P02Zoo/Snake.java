package P02Zoo;

public class Snake extends Reptile{
    public Snake(String name) {
        super(name);
    }
}
