package TrafficLight;

public enum Color {
    RED,
    GREEN,
    YELLOW
}
