package P02HierarchicalInheritance;


public class Animal {

    public void eat() {
        System.out.printf("eating…%n");
    }
}